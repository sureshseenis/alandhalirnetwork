<?php
header('location: ../home');
?>